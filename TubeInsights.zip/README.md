# Tube Insights

Tube Insights is a Python full-stack creator analytics website for estimating video potential, generating titles, descriptions, hashtags, and reviewing video scripts or transcripts.

## Run

```powershell
python app.py
```

Open http://127.0.0.1:8000

## Features

- Analyze video metadata from title, description, likes, comments, and subscribers.
- Generate ranked title ideas from a video description.
- Generate SEO-friendly descriptions from a title.
- Generate viral hashtag sets from a title.
- Analyze video content from a transcript, script, or outline.
- Trend-style output with niche detection, emojis, caption boosters, and special-character hooks.
- Faster editable count controls for likes, comments, and subscribers.

## Model Note

The current version ships with a deterministic local ML-style scoring engine calibrated around creator-growth signals and niche-specific trend packs. It is suitable for prototyping and explainable predictions, but no model can be reliable for every niche without real training data. Use `train_model.py` with a CSV of real video outcomes to start replacing the default weights with channel-specific training.
