"""Tube Insights local AI helpers."""
