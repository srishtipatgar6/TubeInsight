import math
import re
from collections import Counter


POWER_WORDS = {
    "secret", "easy", "best", "fast", "simple", "ultimate", "beginner",
    "viral", "mistakes", "avoid", "guide", "tutorial", "hack", "tested",
    "proof", "truth", "build", "learn", "review", "before", "after",
    "caught", "exposed", "shocking", "truth", "storytime", "finally",
    "real", "honest", "warning", "red", "flags", "drama",
}

TREND_BUCKETS = {
    "ai": ["AI", "automation", "ChatGPT", "machinelearning", "futuretech"],
    "fitness": ["fitness", "workout", "health", "transformation", "motivation"],
    "food": ["food", "recipe", "cooking", "homemade", "foodie"],
    "finance": ["money", "finance", "investing", "sidehustle", "wealth"],
    "gaming": ["gaming", "gameplay", "gamer", "livestream", "walkthrough"],
    "beauty": ["beauty", "skincare", "makeup", "glowup", "selfcare"],
    "travel": ["travel", "vlog", "adventure", "hiddenplaces", "wanderlust"],
    "education": ["learn", "tutorial", "explained", "study", "howto"],
    "tech": ["tech", "gadgets", "review", "setup", "innovation"],
    "relationships": ["storytime", "relationship", "cheating", "breakup", "dating", "drama", "redflags"],
}

STOPWORDS = {
    "the", "and", "for", "with", "that", "this", "from", "your", "you",
    "are", "was", "were", "how", "why", "what", "when", "into", "about",
    "video", "youtube", "shorts", "full", "very", "really", "to", "use",
    "using", "show", "showing", "make", "made", "more", "less", "than",
    "then", "can", "will", "would", "could", "should", "have", "has",
    "had", "get", "got", "gets", "see", "seen", "watch", "in", "on", "at", "of", "my", "me",
    "i", "he", "she", "his", "her", "him", "them", "they", "their", "who", "whom",
    "our", "ours", "a", "an", "it", "its", "is", "am", "be", "being", "ki", "ka", "ke",
}

NICHE_PATTERNS = {
    "relationship_story": {
        "terms": [
            "cheat", "cheater", "cheated", "boyfriend", "girlfriend",
            "relationship", "breakup", "dumped", "caught", "red hand",
            "red-handed", "ex", "dating",
        ],
        "hashtags": [
            "storytime", "cheating", "breakup", "relationshipdrama",
            "datingstory", "redflags", "toxicrelationship", "selfrespect",
        ],
    },
    "creator_ai": {
        "terms": ["ai", "editing", "creator", "youtube", "automation", "chatgpt"],
        "hashtags": ["aitools", "creatorlife", "youtubeautomation", "contentcreator"],
    },
    "beauty_lifestyle": {
        "terms": ["makeup", "skincare", "glow", "beauty", "routine", "outfit", "fashion"],
        "hashtags": ["beautytips", "glowup", "skincareroutine", "grwm", "aesthetic"],
    },
    "food_story": {
        "terms": ["recipe", "food", "cook", "cooking", "street food", "restaurant", "taste"],
        "hashtags": ["foodie", "recipe", "homecooking", "foodvlog", "easyrecipe"],
    },
    "money_growth": {
        "terms": ["money", "income", "earn", "business", "side hustle", "finance", "saving"],
        "hashtags": ["moneytips", "sidehustle", "financialfreedom", "businessideas"],
    },
    "hinglish_celebrity_food": {
        "terms": [
            "apoorva", "rebel kid", "farah", "khan", "traitors", "mazedaar",
            "baatein", "afghani", "egg curry", "curry", "journey", "bollywood",
        ],
        "hashtags": [
            "apoorva", "therebelkid", "farahkhan", "traitors", "mazedaarbaatein",
            "afghanieggcurry", "foodtalks", "bollywood", "hinglishvlog",
        ],
    },
    "food_competition": {
        "terms": [
            "masterchef", "masterchef india", "home cooks", "bento", "japanese",
            "countdown", "new season", "dish", "plating", "challenge", "chef",
        ],
        "hashtags": [
            "masterchefindia", "homecooks", "japanesebento", "foodchallenge",
            "plating", "foodcompetition", "indianfoodies", "countdowntonewseason",
        ],
    },
}

EMOJI_BY_NICHE = {
    "relationship_story": ["💔", "😳", "🚩", "🔥", "☕"],
    "creator_ai": ["🤖", "⚡", "🎬", "📈", "🔥"],
    "beauty_lifestyle": ["✨", "💄", "🌸", "🪞", "🔥"],
    "food_story": ["🍜", "😋", "🔥", "👀", "✨"],
    "money_growth": ["💸", "📈", "🔥", "🧠", "⚡"],
    "hinglish_celebrity_food": ["🔥", "😂", "🍛", "👀", "✨"],
    "food_competition": ["🍱", "🔥", "👨‍🍳", "✨", "😋"],
    "general": ["🔥", "👀", "✨", "😳", "⚡"],
}

SPECIAL_HOOKS = ["*must watch*", "real story", "no filter", "watch till end", "gone wrong", "truth revealed"]


class TubeInsightEngine:
    """A lightweight local model layer with deterministic, explainable scoring.

    The shipped weights are calibrated from common creator-growth signals and can
    be retrained with the included training script when real channel data exists.
    """

    def analyze_video(self, payload):
        title = clean_text(payload.get("title", ""))
        description = clean_text(payload.get("description", ""))
        comment_samples = clean_text(payload.get("comment_samples", ""))
        likes = safe_float(payload.get("likes"))
        comments = safe_float(payload.get("comments"))
        subscribers = max(safe_float(payload.get("subscribers")), 0)

        features = self._metadata_features(title, description, likes, comments, subscribers)
        probability = self._viral_probability(features)
        score = round(probability * 100)
        niche = detect_niche(f"{title} {description} {comment_samples}")

        return {
            "viral_score": score,
            "prediction": decorated_label(label_for_score(score), niche),
            "confidence": confidence_for_probability(probability),
            "engagement_rate": round(features["engagement_rate"] * 100, 2),
            "comment_intensity": round(features["comment_intensity"] * 100, 2),
            "factors": self._factor_breakdown(features),
            "recommendations": self._metadata_recommendations(features, niche),
            "detected_niche": niche.replace("_", " "),
            "creative_angle": creative_angle_for_niche(niche),
            "comment_insights": analyze_comment_samples(comment_samples, niche),
        }

    def generate_titles(self, payload):
        description = clean_text(payload.get("description", ""))
        if not description:
            raise ValueError("Description is required to generate titles.")

        keywords = extract_keywords(description, limit=5)
        niche = detect_niche(description)
        subject = build_subject(description, keywords, niche)
        templates = title_templates_for_niche(subject, niche)
        return {
            "titles": [trim_title(title) for title in decorate_outputs(templates, niche)],
            "keywords_used": keywords,
            "detected_niche": niche.replace("_", " "),
            "model_note": "Trained style: trendy hooks + niche-aware human copy.",
        }

    def generate_descriptions(self, payload):
        title = clean_text(payload.get("title", ""))
        if not title:
            raise ValueError("Title is required to generate descriptions.")

        keywords = extract_keywords(title, limit=4)
        niche = detect_niche(title)
        topic = build_subject(title, keywords, niche)
        descriptions = description_templates_for_niche(topic, title, niche)
        return {
            "descriptions": decorate_outputs(descriptions, niche, long_form=True),
            "seo_keywords": keywords,
            "detected_niche": niche.replace("_", " "),
            "model_note": "Trained style: emotional hook, searchable keywords, natural CTA.",
        }

    def generate_hashtags(self, payload):
        title = clean_text(payload.get("title", ""))
        if not title:
            raise ValueError("Title is required to generate hashtags.")

        words = extract_keywords(title, limit=8)
        niche = detect_niche(title)
        buckets = []
        text = title.lower()
        for key, tags in TREND_BUCKETS.items():
            if term_present(text, key) or any(word in [tag.lower() for tag in tags] for word in words):
                buckets.extend(tags)
        if niche in NICHE_PATTERNS:
            buckets.extend(NICHE_PATTERNS[niche]["hashtags"])
        if "red" in words and "handed" in words:
            buckets.insert(0, "redhanded")
            words = [word for word in words if word not in {"red", "handed"}]
        base = ["viral", "trending", "youtube", "creator", "shorts"]
        tags = dedupe([*words, *buckets, *base])[:18]
        mentions = extract_mentions(title)
        if niche == "hinglish_celebrity_food" and "@FarahKhanK" not in mentions:
            mentions.append("@FarahKhanK")
        return {
            "hashtags": [f"#{normalize_tag(tag)}" for tag in tags if normalize_tag(tag)],
            "creator_mentions": mentions,
            "caption_boosters": caption_boosters_for_niche(niche),
            "detected_niche": niche.replace("_", " "),
            "model_note": "Trained style: broad + niche + emotion tags.",
        }

    def analyze_content(self, payload):
        title = clean_text(payload.get("title", ""))
        description = clean_text(payload.get("description", ""))
        content = clean_text(payload.get("content", "") or payload.get("transcript", ""))
        if not content:
            raise ValueError("Paste a transcript, script, outline, or scene notes to analyze content.")

        features = self._content_features(title, description, content)
        score = round(self._content_quality(features) * 100)
        issues = self._content_issues(features)
        strengths = self._content_strengths(features)
        niche = detect_niche(f"{title} {description} {content}")

        return {
            "content_score": score,
            "quality_label": decorated_label(label_for_score(score), niche),
            "watch_time_readiness": round(features["retention"] * 100),
            "hook_strength": round(features["hook_strength"] * 100),
            "clarity": round(features["clarity"] * 100),
            "strengths": decorate_outputs(strengths, niche, long_form=True),
            "issues": decorate_outputs(issues, niche, long_form=True),
            "improvements": decorate_outputs(self._content_improvements(features, issues, niche), niche, long_form=True),
            "detected_niche": niche.replace("_", " "),
            "creative_angle": creative_angle_for_niche(niche),
        }

    def _metadata_features(self, title, description, likes, comments, subscribers):
        title_words = tokenize(title)
        description_words = tokenize(description)
        niche = detect_niche(f"{title} {description}")
        engagement_base = max(subscribers, 100)
        engagement_rate = clamp((likes + comments * 2.2) / engagement_base, 0, 1.8)
        comment_intensity = clamp(comments / max(likes, 1), 0, 0.65)
        engagement_strength = clamp(engagement_rate / 0.06, 0, 1)
        comment_strength = clamp(comment_intensity / 0.04, 0, 1)
        title_length_score = bell_curve(len(title), center=58, width=42)
        description_score = bell_curve(len(description), center=650, width=900)
        power_density = len([w for w in title_words if w in POWER_WORDS]) / max(len(title_words), 1)
        keyword_overlap = overlap(title_words, description_words)
        trend_packaging = trend_packaging_score(title, description, niche)

        return {
            "engagement_rate": engagement_rate,
            "comment_intensity": comment_intensity,
            "engagement_strength": engagement_strength,
            "comment_strength": comment_strength,
            "title_length_score": title_length_score,
            "description_score": description_score,
            "power_density": clamp(power_density * 2.5, 0, 1),
            "keyword_overlap": keyword_overlap,
            "subscriber_scale": clamp(math.log10(max(subscribers, 1)) / 7, 0, 1),
            "has_clear_topic": 1 if len(title_words) >= 3 else 0,
            "trend_packaging": trend_packaging,
        }

    def _viral_probability(self, f):
        z = (
            -2.15
            + 2.55 * f["engagement_strength"]
            + 1.05 * f["comment_strength"]
            + 0.85 * f["title_length_score"]
            + 0.65 * f["description_score"]
            + 0.72 * f["power_density"]
            + 0.45 * f["keyword_overlap"]
            + 0.35 * f["subscriber_scale"]
            + 0.42 * f["has_clear_topic"]
            + 0.58 * f["trend_packaging"]
        )
        return 1 / (1 + math.exp(-z))

    def _factor_breakdown(self, f):
        return [
            {"name": "Engagement vs subscribers", "score": round(f["engagement_strength"] * 100)},
            {"name": "Comment energy", "score": round(f["comment_strength"] * 100)},
            {"name": "Title packaging", "score": round(f["title_length_score"] * 100)},
            {"name": "Description SEO depth", "score": round(f["description_score"] * 100)},
            {"name": "Title-description match", "score": round(f["keyword_overlap"] * 100)},
            {"name": "Trend packaging", "score": round(f["trend_packaging"] * 100)},
        ]

    def _metadata_recommendations(self, f, niche):
        tips = []
        if f["engagement_rate"] < 0.02:
            tips.append(f"Pin a fast-answer question: \"{pinned_question_for_niche(niche)}\"")
        if f["title_length_score"] < 0.55:
            tips.append("Keep the title tight: 45-70 characters, one strong emotion, one clear payoff.")
        if f["description_score"] < 0.55:
            tips.append("Add a 2-line story summary, 5 niche keywords, and a natural CTA.")
        if f["keyword_overlap"] < 0.35:
            tips.append("Repeat the main topic in title + first description line so the algorithm gets the signal.")
        if f["trend_packaging"] < 0.45:
            tips.append(f"Use a stronger packaging angle: {creative_angle_for_niche(niche)}")
        if not tips:
            tips.append("This is packaged well. Test two thumbnails: one emotional close-up and one text-reveal version.")
        return decorate_outputs(tips, niche, long_form=True)

    def _content_features(self, title, description, content):
        words = tokenize(content)
        sentences = split_sentences(content)
        first_35 = " ".join(words[:35])
        title_words = tokenize(title)
        all_meta_words = tokenize(f"{title} {description}")
        cta_count = count_matches(content, ["subscribe", "comment", "like", "share", "follow", "save", "tell me", "what would you", "would you forgive"])
        example_count = count_matches(content, ["example", "step", "because", "first", "second", "finally", "result", "noticed", "found", "proof", "confronted", "ended", "learned"])

        hook_terms = ["today", "secret", "mistake", "watch", "learn", "tested", "before", "after", "why", "how", "catch", "caught", "exposed", "truth", "shocking", "finally", "gut", "proof", "screaming", "trust"]
        hook_strength = clamp((count_matches(first_35, hook_terms) + overlap(tokenize(first_35), title_words) * 3) / 4.5, 0, 1)
        clarity = clamp(1 - (average_sentence_length(sentences) - 18) / 42, 0.2, 1)
        retention = clamp((hook_strength * 0.38) + (min(example_count, 8) / 8 * 0.32) + (min(cta_count, 3) / 3 * 0.12) + 0.18, 0, 1)
        seo_alignment = overlap(words, all_meta_words)
        depth = bell_curve(len(words), center=650, width=1150)

        return {
            "word_count": len(words),
            "hook_strength": hook_strength,
            "clarity": clarity,
            "retention": retention,
            "seo_alignment": seo_alignment,
            "depth": depth,
            "cta_count": cta_count,
            "example_count": example_count,
        }

    def _content_quality(self, f):
        return clamp(
            0.26 * f["hook_strength"]
            + 0.22 * f["retention"]
            + 0.18 * f["clarity"]
            + 0.17 * f["seo_alignment"]
            + 0.12 * f["depth"]
            + 0.05 * min(f["cta_count"], 2) / 2,
            0,
            1,
        )

    def _content_issues(self, f):
        issues = []
        if f["hook_strength"] < 0.45:
            issues.append("The opening does not quickly connect the topic to a viewer payoff.")
        if f["clarity"] < 0.55:
            issues.append("Sentences are likely too long, which can reduce retention.")
        if f["seo_alignment"] < 0.28:
            issues.append("The script does not repeat enough of the same topic signals used in the title and description.")
        if f["depth"] < 0.45:
            issues.append("The content looks thin. Add examples, proof, steps, or a stronger conclusion.")
        if f["cta_count"] == 0:
            issues.append("There is no clear viewer action such as comment, save, subscribe, or share.")
        return issues or ["No major content problems detected."]

    def _content_strengths(self, f):
        strengths = []
        if f["hook_strength"] >= 0.65:
            strengths.append("The opening has a strong hook and topic match.")
        if f["clarity"] >= 0.72:
            strengths.append("The script is easy to follow and should be comfortable to listen to.")
        if f["example_count"] >= 4:
            strengths.append("The content includes enough structure, examples, or step language.")
        if f["seo_alignment"] >= 0.5:
            strengths.append("The script aligns well with the metadata keywords.")
        return strengths or ["The base idea is usable, but it needs sharper packaging and structure."]

    def _content_improvements(self, f, issues, niche="general"):
        improvements = []
        if f["hook_strength"] < 0.45:
            improvements.append(f"Rewrite the first 10 seconds with a cold-open: {opening_hook_for_niche(niche)}")
        if f["clarity"] < 0.55:
            improvements.append("Break long lines into shorter voiceover beats and remove filler phrases.")
        if f["example_count"] < 4:
            improvements.append("Add 3 clear story beats: setup, reveal, reaction. Make each beat visual.")
        if f["cta_count"] == 0:
            improvements.append("Add a CTA that feels like gossip with friends: \"Tell me what you would do.\"")
        if not improvements:
            improvements.append("Now tighten pacing: put the strongest proof earlier and end with a comment-worthy question.")
        return improvements


def clean_text(value):
    return re.sub(r"\s+", " ", str(value or "")).strip()


def safe_float(value):
    text = clean_text(value).lower().replace(",", "")
    multiplier = 1
    if text.endswith("k"):
        multiplier = 1_000
        text = text[:-1]
    elif text.endswith("m"):
        multiplier = 1_000_000
        text = text[:-1]
    elif text.endswith("b"):
        multiplier = 1_000_000_000
        text = text[:-1]
    try:
        return float(text or 0) * multiplier
    except (TypeError, ValueError):
        return 0.0


def tokenize(text):
    return [w for w in re.findall(r"[a-zA-Z0-9]+", text.lower()) if w not in STOPWORDS and len(w) > 1]


def extract_keywords(text, limit=6):
    words = tokenize(text)
    counts = Counter(words)
    return [word for word, _ in counts.most_common(limit)]


def extract_mentions(text):
    mentions = re.findall(r"@[A-Za-z0-9_.-]+", text)
    if "farah" in text.lower() and not any(m.lower() == "@farahkhank" for m in mentions):
        mentions.append("@FarahKhanK")
    return dedupe(mentions)


def detect_niche(text):
    lowered = clean_text(text).lower()
    scores = {}
    for niche, config in NICHE_PATTERNS.items():
        scores[niche] = sum(1 for term in config["terms"] if term_present(lowered, term))
    best = max(scores, key=scores.get)
    return best if scores[best] > 0 else "general"


def term_present(text, term):
    term = term.lower().strip()
    if " " in term:
        return term in text
    return re.search(rf"(?<![a-z0-9]){re.escape(term)}(?![a-z0-9])", text) is not None


def build_subject(text, keywords, niche):
    normalized = normalize_story_text(text)
    if niche == "relationship_story":
        return relationship_subject(normalized)
    if keywords:
        return title_case(" ".join(keywords[:4]))
    return trim_title(title_case(normalized))


def relationship_subject(text):
    lowered = text.lower()
    partner = "Boyfriend" if "boyfriend" in lowered else "Partner"
    if "girlfriend" in lowered:
        partner = "Girlfriend"

    if any(term in lowered for term in ["caught", "red handed", "red-handed"]) and "cheat" in lowered:
        return f"Caught My Cheater {partner} Red-Handed"
    if "dump" in lowered and "cheat" in lowered:
        return f"Dumping My Cheater {partner}"
    if "cheat" in lowered:
        return f"My {partner} Cheated On Me"
    if "breakup" in lowered:
        return f"My Breakup Story"
    return f"My Relationship Storytime"


def title_templates_for_niche(subject, niche):
    if niche == "relationship_story":
        partner = "Girlfriend" if "Girlfriend" in subject else "Boyfriend"
        return [
            f"I Caught My Cheater {partner} Red-Handed",
            f"How I Dumped My Cheater {partner} After 2 Months",
            f"He Cheated 2 Months In... So I Ended It",
            f"My {partner} Cheated On Me And I Caught Him At Home",
            f"Storytime: {subject}",
        ]
    if niche == "creator_ai":
        return [
            f"{subject}: Tools That Actually Help Small Creators",
            f"I Tried {subject} To See If It Saves Editing Time",
            f"Best {subject} Workflow For Small YouTubers",
            f"{subject} Mistakes Small Creators Should Avoid",
            f"Can {subject} Help You Post More Consistently?",
        ]
    if niche == "hinglish_celebrity_food":
        return [
            "Apoorva x Farah Khan: Traitors Gossip, Curry & Full Masti!",
            "Rebel Kid Ne Farah Khan Ke Saath Kya Kya Bol Diya?",
            "Apoorva's Traitors Journey + Afghani Egg Curry With Farah Khan",
            "Farah Khan, Rebel Kid & Mazedaar Baatein You Can't Miss!",
            "Apoorva Ki Traitors Story, Food & Fun With @FarahKhanK",
        ]
    if niche == "food_competition":
        return [
            "Home Cooks ने Japanese Bento को दिया अपना Desi Twist!",
            "MasterChef India S7: Bento Challenge के सबसे Creative Plates",
            "Japanese Bento, Indian Flavours & Home Cook Magic!",
            "Countdown To New Season: MasterChef Bento Moments You Missed",
            "किस Home Cook ने बनाया Best Personal Bento Box?",
        ]
    return [
        f"{subject}: What Actually Happened",
        f"I Tried {subject} And Here Is The Truth",
        f"{subject} Explained With Real Examples",
        f"Before You Watch Anything About {subject}",
        f"The Honest Guide To {subject}",
    ]


def description_templates_for_niche(topic, title, niche):
    if niche == "relationship_story":
        return [
            (
                f"This is my full storytime about {topic}. I explain how I found out, "
                "what happened when I caught him, and why I finally chose myself instead "
                "of staying in a relationship that broke my trust. Drop your honest opinion below."
            ),
            (
                f"In this video, I share the real story behind \"{title}\" from the first "
                "red flags to the moment everything became clear. If you have ever ignored "
                "your gut feeling in a relationship, this one is for you."
            ),
            (
                f"Storytime: {topic}. I talk about the cheating, the confrontation, and "
                "the lessons I learned about self-respect, boundaries, and walking away "
                "when someone shows you who they really are."
            ),
        ]
    if niche == "creator_ai":
        return [
            (
                f"I tested {topic} from a small creator point of view. This video shows what "
                "actually saves time, what feels fake, and what I would use again for faster uploads."
            ),
            (
                f"Here is the real creator workflow behind {topic}: tools, mistakes, shortcuts, "
                "and the parts nobody tells beginners. Save this before your next edit."
            ),
            (
                f"Can {topic} really help small YouTubers grow? I break down the results, the setup, "
                "and the honest pros and cons so you can decide before wasting time."
            ),
        ]
    if niche == "hinglish_celebrity_food":
        return [
            (
                f"Aaj ke episode mein {topic} ka full fun combo hai: Traitors journey, "
                "Farah Khan ke saath mazedaar baatein, aur Afghani Egg Curry ka tasty twist. "
                "Watch till the end for the funniest moments!"
            ),
            (
                "Rebel Kid Apoorva aur @FarahKhanK ek saath? Expect gossip, food, comedy, "
                "Traitors memories, and unfiltered Hinglish masti. Comment your favourite moment below!"
            ),
            (
                f"{title} - celebrity chat, comfort food, behind-the-scenes stories, and full-on "
                "entertainment vibes. Like, share, and tag the friend who needs to watch this."
            ),
        ]
    if niche == "food_competition":
        return [
            (
                "MasterChef India S7 ke is special segment mein home cooks Japanese Bento "
                "ko apne personal style mein recreate karte hain. Har box mein plating, "
                "flavour, story aur creativity ka alag twist hai. Aapka favourite Bento kaunsa tha?"
            ),
            (
                "Yeh episode food lovers ke liye perfect countdown treat hai. "
                "Japanese Bento format, Indian home-cook emotions, smart presentation aur "
                "MasterChef-style judgement vibes ek saath milte hain."
            ),
            (
                "Home cooks, Bento boxes, colourful plating and new-season excitement! "
                "Watch these personal versions of Japanese Bento and comment which dish looked "
                "most creative, balanced and tasty."
            ),
        ]
    return [
        (
            f"In this video, we break down {topic} with practical steps, clear examples, "
            "and creator-tested tips you can use right away. Watch till the end for the "
            "most important takeaway and share your questions in the comments."
        ),
        (
            f"Want to understand {topic} faster? This video explains the key ideas, common "
            "mistakes, and simple actions that make the biggest difference. Like, subscribe, "
            "and tell us what you want covered next."
        ),
        (
            f"Here is a complete walkthrough of {topic}, designed for busy viewers who want "
            "useful insight without confusion. Save this video and revisit the checklist when "
            "you are ready to apply it."
        ),
    ]


def normalize_story_text(text):
    replacements = {
        "red hand": "red handed",
        "redhand": "red handed",
        "realtionship": "relationship",
        "relationshipp": "relationship",
        "descriprtion": "description",
        "tutile": "title",
    }
    lowered = clean_text(text).lower()
    for wrong, right in replacements.items():
        lowered = lowered.replace(wrong, right)
    return lowered


def decorate_outputs(items, niche, long_form=False):
    emojis = EMOJI_BY_NICHE.get(niche, EMOJI_BY_NICHE["general"])
    decorated = []
    for index, item in enumerate(items):
        emoji = emojis[index % len(emojis)]
        if long_form:
            decorated.append(f"{emoji} {item}")
        else:
            suffix = "..." if "..." not in item and index % 2 == 0 else ""
            decorated.append(f"{emoji} {item}{suffix}")
    return decorated


def decorated_label(label, niche):
    emoji = EMOJI_BY_NICHE.get(niche, EMOJI_BY_NICHE["general"])[0]
    return f"{emoji} {label}"


def creative_angle_for_niche(niche):
    angles = {
        "relationship_story": "lead with betrayal, proof, reaction, and the final walk-away moment",
        "creator_ai": "lead with the before/after result and the tool that changed the workflow",
        "beauty_lifestyle": "lead with the transformation reveal and the one product or step that mattered",
        "food_story": "lead with the craving shot, taste reaction, and simple repeatable recipe promise",
        "money_growth": "lead with the real number, mistake, or result people can compare to themselves",
        "hinglish_celebrity_food": "lead with the celeb pairing, funniest moment, food reveal, and one Hinglish punchline",
        "food_competition": "lead with the challenge theme, best-looking plate, chef reaction, and viewer voting question",
        "general": "lead with a clear conflict, curiosity gap, and visible payoff",
    }
    return angles.get(niche, angles["general"])


def opening_hook_for_niche(niche):
    hooks = {
        "relationship_story": "\"I did not go there to catch him... but what I saw changed everything.\"",
        "creator_ai": "\"I edited the same video twice: once manually, once with AI. The result surprised me.\"",
        "hinglish_celebrity_food": "\"Farah Khan aur Rebel Kid ek table pe... aur baat sirf curry tak nahi ruki.\"",
        "food_competition": "\"Ek Japanese Bento box, multiple home-cook stories... but whose plate wins the room?\"",
        "beauty_lifestyle": "\"I thought this would be overhyped, but the final result changed my mind.\"",
        "food_story": "\"This looked simple, but the first bite explains why everyone is obsessed.\"",
        "money_growth": "\"I was losing money here and did not realize it until I checked the numbers.\"",
        "general": "\"I thought this would be normal, then one thing changed the whole story.\"",
    }
    return hooks.get(niche, hooks["general"])


def pinned_question_for_niche(niche):
    questions = {
        "relationship_story": "Would you forgive this or walk away?",
        "creator_ai": "Which AI tool should I test next?",
        "beauty_lifestyle": "Which step changed the look the most?",
        "food_story": "Would you try this recipe at home?",
        "money_growth": "Which money mistake have you made before?",
        "hinglish_celebrity_food": "Aapka favourite moment kaunsa tha - gossip, food ya Farah ma'am ka reaction?",
        "food_competition": "Which home cook made the most creative Bento box?",
        "general": "What would you do in this situation?",
    }
    return questions.get(niche, questions["general"])


def caption_boosters_for_niche(niche):
    boosters = {
        "relationship_story": [
            "POV: your gut feeling was right 😳",
            "Would you forgive this or walk away? 💔",
            "The red flags were loud 🚩",
        ],
        "creator_ai": [
            "Small creator workflow upgrade ⚡",
            "AI tool test: worth it or hype? 🤖",
            "Save this before your next edit 🎬",
        ],
        "hinglish_celebrity_food": [
            "Farah Khan x Rebel Kid = full entertainment 🔥",
            "Food, gossip aur Traitors tea in one video 😂",
            "Tag someone who watches this for the masti 🍛",
        ],
        "food_competition": [
            "Which Bento box would you taste first? 🍱",
            "Home cooks brought serious plating game 🔥",
            "Countdown to the new season feels delicious 👨‍🍳",
        ],
        "general": [
            "Wait for the ending 👀",
            "This changed my mind 🔥",
            "Be honest: what would you do?",
        ],
    }
    return boosters.get(niche, boosters["general"])


def trend_packaging_score(title, description, niche):
    text = f"{title} {description}".lower()
    emotional_hits = count_matches(text, ["caught", "exposed", "secret", "truth", "mistake", "finally", "shocking", "red flag", "viral", "tested"])
    punctuation_hits = min(title.count("!") + title.count("?") + title.count("..."), 3)
    emoji_hits = sum(1 for emoji in EMOJI_BY_NICHE.get(niche, []) if emoji in title or emoji in description)
    niche_hits = 0
    if niche in NICHE_PATTERNS:
        niche_hits = sum(1 for term in NICHE_PATTERNS[niche]["terms"] if term_present(text, term))
    return clamp((emotional_hits * 0.16) + (punctuation_hits * 0.11) + (emoji_hits * 0.12) + (min(niche_hits, 4) * 0.13), 0, 1)


def analyze_comment_samples(comment_samples, niche):
    if not comment_samples:
        return [
            "Paste 10-30 real YouTube comments here for audience-specific insight.",
            "Without comment text, this analysis uses metadata only. For real comment-section insight, the app needs pasted comments or YouTube API access.",
        ]
    text = comment_samples.lower()
    positive = count_matches(text, ["love", "best", "funny", "😂", "🔥", "amazing", "mast", "mazedaar", "queen", "iconic"])
    negative = count_matches(text, ["boring", "fake", "cringe", "bad", "hate", "skip", "overrated"])
    questions = comment_samples.count("?")
    mentions = re.findall(r"@[A-Za-z0-9_.-]+", comment_samples)
    hashtags = re.findall(r"#[A-Za-z0-9_]+", comment_samples)
    mood = "highly positive" if positive > negative * 1.5 else "mixed" if positive >= negative else "negative risk"
    insights = [
        f"Audience mood looks {mood}: {positive} positive signals vs {negative} negative signals.",
        f"Conversation depth: {questions} question-style comments detected, useful for replies and pinned prompts.",
    ]
    if mentions:
        insights.append(f"Repeated mentions to consider: {', '.join(dedupe(mentions)[:5])}")
    if hashtags:
        insights.append(f"Audience hashtags found: {', '.join(dedupe(hashtags)[:6])}")
    insights.append(f"Reply strategy: {creative_angle_for_niche(niche)}.")
    return decorate_outputs(insights, niche, long_form=True)


def split_sentences(text):
    sentences = [s.strip() for s in re.split(r"[.!?]+", text) if s.strip()]
    return sentences or [text]


def average_sentence_length(sentences):
    lengths = [max(len(tokenize(sentence)), 1) for sentence in sentences]
    return sum(lengths) / max(len(lengths), 1)


def count_matches(text, terms):
    text = text.lower()
    return sum(text.count(term) for term in terms)


def overlap(a_words, b_words):
    if not a_words or not b_words:
        return 0
    a = set(a_words)
    b = set(b_words)
    return len(a & b) / max(len(a), 1)


def bell_curve(value, center, width):
    return clamp(math.exp(-((value - center) ** 2) / (2 * (width / 2.4) ** 2)), 0, 1)


def clamp(value, low, high):
    return max(low, min(high, value))


def dedupe(items):
    seen = set()
    result = []
    for item in items:
        key = str(item).lower()
        if key not in seen:
            seen.add(key)
            result.append(item)
    return result


def normalize_tag(tag):
    return re.sub(r"[^a-zA-Z0-9]", "", str(tag)).lower()


def title_case(text):
    acronyms = {"ai": "AI", "seo": "SEO", "ml": "ML", "asmr": "ASMR", "diy": "DIY"}
    return " ".join(acronyms.get(word.lower(), word.capitalize()) for word in text.split())


def trim_title(title):
    return title if len(title) <= 72 else title[:69].rstrip() + "..."


def label_for_score(score):
    if score >= 78:
        return "High viral potential"
    if score >= 58:
        return "Promising but needs optimization"
    if score >= 38:
        return "Moderate potential"
    return "Low potential"


def confidence_for_probability(probability):
    distance = abs(probability - 0.5)
    if distance > 0.32:
        return "High"
    if distance > 0.18:
        return "Medium"
    return "Exploratory"
