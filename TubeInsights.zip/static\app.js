const toolTitles = {
  analyze: "Video Viral Analyzer",
  titles: "Title Generator",
  descriptions: "Description Generator",
  hashtags: "Viral Hashtag Generator",
  content: "Content Quality Analyzer",
  about: "About Tube Insights",
};

document.querySelectorAll(".tab").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((tab) => tab.classList.remove("active"));
    document.querySelectorAll(".tool-panel").forEach((panel) => panel.classList.remove("active"));
    button.classList.add("active");
    document.getElementById(button.dataset.tab).classList.add("active");
    document.getElementById("tool-title").textContent = toolTitles[button.dataset.tab];
  });
});

document.querySelectorAll("form[data-endpoint]").forEach((form) => {
  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const target = resultTarget(form);
    target.innerHTML = `<div class="empty">Analyzing with the local model...</div>`;

    const payload = Object.fromEntries(new FormData(form).entries());
    const response = await fetch(form.dataset.endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await response.json();
    if (!response.ok) {
      target.innerHTML = `<div class="empty">${escapeHtml(data.error || "Something went wrong")}</div>`;
      return;
    }
    renderers[form.dataset.render](data, target);
  });
});

document.querySelectorAll(".number-editor button[data-step]").forEach((button) => {
  button.addEventListener("click", () => {
    const input = button.parentElement.querySelector("input");
    const next = Math.max(0, parseCount(input.value) + Number(button.dataset.step));
    input.value = next;
  });
});

document.querySelectorAll(".quick-values button[data-value]").forEach((button) => {
  button.addEventListener("click", () => {
    const input = button.closest("label").querySelector("input");
    input.value = button.dataset.value;
  });
});

function resultTarget(form) {
  if (form.dataset.target) return document.getElementById(form.dataset.target);
  return form.closest(".tool-panel").querySelector(".result");
}

const renderers = {
  renderAnalysis(data, target) {
    target.innerHTML = `
      ${resultMeta(data)}
      ${scoreBlock(data.viral_score, data.prediction, `Confidence: ${data.confidence}`)}
      ${data.creative_angle ? `<p class="angle">${escapeHtml(data.creative_angle)}</p>` : ""}
      <p><strong>Engagement rate:</strong> ${data.engagement_rate}%</p>
      <p><strong>Comment intensity:</strong> ${data.comment_intensity}%</p>
      <h3 class="section-title">Model Factors</h3>
      <div class="metrics">${data.factors.map(metricBlock).join("")}</div>
      <h3 class="section-title">Recommendations</h3>
      <ul class="list">${data.recommendations.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>
      ${data.comment_insights ? `<h3 class="section-title">Comment Insights</h3><ul class="list">${data.comment_insights.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>` : ""}
    `;
  },
  renderList(data, target) {
    const items = data.titles || data.descriptions || [];
    target.innerHTML = `
      ${resultMeta(data)}
      <ul class="list">${items.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>
    `;
  },
  renderTags(data, target) {
    target.innerHTML = `
      ${resultMeta(data)}
      ${data.creator_mentions && data.creator_mentions.length ? `<h3 class="section-title">Mentions</h3><div class="tags">${data.creator_mentions.map((tag) => `<span class="tag mention">${escapeHtml(tag)}</span>`).join("")}</div>` : ""}
      <div class="tags">${data.hashtags.map((tag) => `<span class="tag">${escapeHtml(tag)}</span>`).join("")}</div>
      ${data.caption_boosters ? `<h3 class="section-title">Caption Boosters</h3><ul class="list">${data.caption_boosters.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>` : ""}
    `;
  },
  renderContent(data, target) {
    target.innerHTML = `
      ${resultMeta(data)}
      ${scoreBlock(data.content_score, data.quality_label, `Watch-time readiness: ${data.watch_time_readiness}%`)}
      ${data.creative_angle ? `<p class="angle">${escapeHtml(data.creative_angle)}</p>` : ""}
      <div class="metrics">
        ${metricBlock({ name: "Hook strength", score: data.hook_strength })}
        ${metricBlock({ name: "Clarity", score: data.clarity })}
      </div>
      <h3 class="section-title">Strengths</h3>
      <ul class="list">${data.strengths.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>
      <h3 class="section-title">Issues</h3>
      <ul class="list">${data.issues.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>
      <h3 class="section-title">Improvements</h3>
      <ul class="list">${data.improvements.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>
    `;
  },
};

function scoreBlock(score, label, subline) {
  return `
    <div class="score">
      <strong>${Number(score)}</strong>
      <span>${escapeHtml(label)} - ${escapeHtml(subline)}</span>
      <div class="bar"><i style="width:${Math.max(2, Number(score))}%"></i></div>
    </div>
  `;
}

function metricBlock(metric) {
  return `
    <article class="metric">
      <header><span>${escapeHtml(metric.name)}</span><span>${Number(metric.score)}%</span></header>
      <div class="bar"><i style="width:${Math.max(2, Number(metric.score))}%"></i></div>
    </article>
  `;
}

function resultMeta(data) {
  const parts = [];
  if (data.detected_niche) parts.push(`Niche: ${data.detected_niche}`);
  if (data.model_note) parts.push(data.model_note);
  return parts.length ? `<p class="meta-line">${parts.map(escapeHtml).join(" - ")}</p>` : "";
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function parseCount(value) {
  const text = String(value || "0").trim().toLowerCase().replaceAll(",", "");
  const multiplier = text.endsWith("k") ? 1000 : text.endsWith("m") ? 1000000 : text.endsWith("b") ? 1000000000 : 1;
  const numeric = multiplier === 1 ? text : text.slice(0, -1);
  return Number(numeric) * multiplier || 0;
}
